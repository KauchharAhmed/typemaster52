@extends('admin.masterAdmin')
@section('content')

<div id="page_content">
        <div id="page_content_inner">
            <!-- large chart -->
			<h3 class="heading_b uk-margin-bottom">EXAM RESULT</h3>
            <div class="md-card uk-margin-medium-bottom">
                <div class="md-card-content">
                    <table class="uk-table uk-table-no-border uk-text-nowrap">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Name</th>
                                <th>Exam Session</th>
                                <th>Marks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($query as $value) { ?>
                            <tr>
                                <td><?php echo $value->student_email; ?></td>
                                <td><?php echo $value->student_name_english; ?></td>
                                <td><?php echo $value->step_name; ?></td>
                                <td><b><?php echo number_format($value->score,2); ?>%</b></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div><!-- end database -->
        </div>
    </div>
@endsection