@extends('admin.masterEntrerpreneur')
@section('content')
<div id="page_content">
        <div id="page_content_inner">

            <!-- large chart -->
            <div class="uk-grid">
                <div class="uk-width-2-3">
                    <div class="md-card">
                
                  <div class="user_heading user_heading_bg" style="background-image: url('public/assets/img/gallery/Image10.jpg');background-size:cover;">
                    <div class="bg_overlay">
                        <div class="user_heading_menu hidden-print">
                            <div class="uk-display-inline-block" data-uk-dropdown="{pos:'left-top'}">
                                <i class="md-icon material-icons md-icon-light">&#xE5D4;</i>
                                <div class="uk-dropdown uk-dropdown-small">
                                    <ul class="uk-nav">
                                        <li><a href="#" id="updateProfile">Update Profile</a></li>
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                        <div class="user_heading_avatar">
                            <div class="thumbnail">
                                <img src="{{ URL::to('public/images/user') }}/{{ Session::get('photo') }}" alt="Admin"/>
                            </div>
                        </div>
                        <?php $adminQuery = DB::table('admin')->where('id',Session::get('admin_id'))->first(); ?>
                        <div class="user_heading_content">
                            <h2 class="heading_b uk-margin-bottom"><span class="uk-text-truncate"><?php echo $adminQuery->student_name_english; ?></span><span class="sub-heading">Admin</span></h2>
                            <ul class="user_stats">
                                <li>
                                    <h4 class="heading_a">E-mail <span class="sub-heading"><?php echo $adminQuery->student_email; ?></span></h4>
                                </li>
                                <li>
                                    <h4 class="heading_a">Mobile <span class="sub-heading"><?php echo $adminQuery->student_mobile; ?></span></h4>
                                </li>
                                <li>
                                    <h4 class="heading_a">Address <span class="sub-heading"><?php echo $adminQuery->per_village; ?></span></h4>
                                </li>
                            </ul>
                        </div>
                    </div>
                  </div>
            </div>
                    <div class="md-card">
                        <div class="md-card-toolbar" style="color:yellow;background: -webkit-gradient(linear, left top, left bottom, from(#42a1ec), to(#0070c9));background: -webkit-linear-gradient(#42a1ec, #0070c9);background: linear-gradient(#42a1ec, #0070c9);font-size:17px;font-weight:bold;">
                            <h3 class="md-card-toolbar-heading-text" style="color:#fff;font-size:17px;font-weight:bold;">Your Exam Result</h3>
                            
                        </div>
                        <div class="md-card-content" style="background:#efffd8;font-size:27px;font-weight:bold;border-bottom:2px solid #42a1ec;border-left:2px solid #42a1ec;border-right:2px solid #42a1ec;text-align:justify;">

                            <table>
                                <tr>
                                    <td>Total Word</td>
                                    <td>&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;</td>
                                    <td><?php echo $result->word; ?></td>
                                </tr>
                                <tr>
                                    <td>Typed Word</td>
                                    <td>&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;</td>
                                    <td><?php echo $result->typed_word; ?></td>
                                </tr>
                                <tr>
                                    <td>Wrong Word</td>
                                    <td>&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;</td>
                                    <td><?php echo $result->wrong_word; ?></td>
                                </tr>
                                <tr>
                                    <td>Correct Word</td>
                                    <td>&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;</td>
                                    <td><?php $correct_word = $result->typed_word - $result->wrong_word ; echo $correct_word;   ?></td>
                                </tr>
                                <tr>
                                    <td>Score</td>
                                    <td>&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;</td>
                                    <td><?php echo $result->score; ?>%</td>
                                </tr>
                            </table>

                        </div>
                    </div>
                </div>

                <div class="uk-width-2-6">

                </div>
            </div>

        </div>
    </div>
@endsection

@section('js')

@endsection