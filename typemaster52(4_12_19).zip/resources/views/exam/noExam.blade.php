@extends('admin.masterEntrerpreneur')
@section('content')
<div id="page_content">
        <div id="page_content_inner">
            <?php
            $session_Query = DB::table('admin')->where('id',Session::get('admin_id'))->first();
            $session_id = $session_Query->step_id;

            $amountQuery = DB::table('tbl_step')->where('id',$session_id)->first();

            ?>

            <!-- large chart -->
            <div class="uk-grid">
                <div class="uk-width-2-5">
                    <div class="md-card">
                        <div class="md-card-toolbar" style="color:yellow;background: -webkit-gradient(linear, left top, left bottom, from(#42a1ec), to(#0070c9));background: -webkit-linear-gradient(#42a1ec, #0070c9);background: linear-gradient(#42a1ec, #0070c9);font-size:17px;font-weight:bold;">
                            <h3 class="md-card-toolbar-heading-text" style="color:#fff;font-size:17px;font-weight:bold;">Pay to attend in exam first via Bkash</h3>
                        </div>
                        <div class="md-card-content" style="background:#efffd8;font-size:18px;font-weight:bold;border-bottom:2px solid #42a1ec;border-left:2px solid #42a1ec;border-right:2px solid #42a1ec;text-align:justify;">
                            <p class="paragraph">Send at: 01723626707 (<?php echo '৳'.$amountQuery->amount; ?>)</p>
                            
                            {!! Form::open(['url' =>'paymentByBkash','method' => 'post','role' => 'form']) !!}

                            <input type="hidden" name="paragraph_id" value="{{ $paragraph_id }}">
                            <input type="hidden" name="session_id" value="{{ $session_id }}">
                            
                            <table>
                                <tr>
                                    <td style="font-size:14px !important;">Amount</td>
                                    <td><input type="text" name="amount"></td>
                                </tr>
                                <tr>
                                    <td style="font-size:14px !important;">Sent from</td>
                                    <td><input type="text" name="bkash_number"></td>
                                </tr>
                                <tr>
                                    <td style="font-size:14px !important;">Transanction ID</td>
                                    <td><input type="text" name="txrid"></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><input type="submit" class="md-btn md-btn-primary md-btn" id="formSubmit" value="Pay Now"></td>
                                </tr>
                            </table>

                            {!! Form::close() !!}

                        </div>

                    </div>

                </div>
                <div class="uk-width-2-4">
                    <div class="md-card">
                        <div class="md-card-toolbar" style="color:yellow;background: -webkit-gradient(linear, left top, left bottom, from(#42a1ec), to(#0070c9));background: -webkit-linear-gradient(#42a1ec, #0070c9);background: linear-gradient(#42a1ec, #0070c9);font-size:17px;font-weight:bold;">
                            <h3 class="md-card-toolbar-heading-text" style="color:#fff;font-size:17px;font-weight:bold;">Bkash Payment Details Title </h3>
                        </div>
                        <div class="md-card-content" style="background:#efffd8;font-size:18px;font-weight:bold;border-bottom:2px solid #42a1ec;border-left:2px solid #42a1ec;border-right:2px solid #42a1ec;text-align:justify;">
                            <p class="paragraph">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their.sdasdasdasdasd.</p>
                            
                            

                        </div>

                    </div>

                </div>

            </div>

        </div>
    </div>
@endsection