<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Smart Typing || Signin</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(URL::to('public/website/vendor/waves/waves.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::to('public/website/vendor/owlcarousel/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::to('public/website/css/style.css')); ?>">
</head>

<body>

    <!-- <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div> -->

    <div id="main-wrapper">

        <div class="header">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <nav class="navbar navbar-expand-lg navbar-light px-0 justify-content-between">
                            <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>"><img src="images/w_logo.png" alt="">
                                <span>Smart-typing</span></a>

                            <div class="dashboard_log">
                                <div class="d-flex align-items-center">
                                    <div class="header_auth">
                                        <a href="<?php echo e(URL::to('signin')); ?>" class="btn btn-success  mx-2">Sign In</a>
                                        <a href="<?php echo e(URL::to('userSignUp')); ?>" class="btn btn-outline-primary  mx-2">Sign Up</a>
                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>


        <div class="authincation section-padding">
            <div class="container h-100">
                <div class="row justify-content-center h-100 align-items-center">
                    <div class="col-xl-4 col-md-6">
                        <div class="auth-form card">
                            <div class="card-header justify-content-center">
                                <h4 class="card-title">Sign in</h4>

                            </div>
                            <div class="card-body">
                                <?php
                        if(Session::get('login_faild') != null) { ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                        <a href="#" class="fa fa-times" data-dismiss="alert" aria-label="close"></a>
                        <strong><?php echo Session::get('login_faild') ; ?></strong>
                        <?php echo Session::put('login_faild',null) ; ?>
                        </div>
                        <?php } ?>

                        <?php if(count($errors) > 0): ?>
                        <?php foreach($errors->all() as $error): ?>      
                        <div class="alert alert-danger alert-dismissible" role="alert">
                        <a href="#" class="fa fa-times" data-dismiss="alert" aria-label="close"></a>
                        <strong><?php echo e($error); ?></strong>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>  
                                <?php echo Form::open(['url' => 'userloginProcess','method' => 'post' , 'class'=> 'signin_validate' , 'name'=> '' ]); ?>

                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" class="form-control" placeholder="Username (E-mail)" name="login_username" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" class="form-control" placeholder="Password" name="login_password" required>
                                    </div>
                                    <div class="form-row d-flex justify-content-between mt-4 mb-2">
                                        <div class="form-group mb-0">
                                            <label class="toggle">
                                                <input class="toggle-checkbox" type="checkbox">
                                                <div class="toggle-switch"></div>
                                                <span class="toggle-label">Remember me</span>
                                            </label>
                                        </div>
                                        <div class="form-group mb-0" style="display: none;">
                                            <a href="#">Forgot Password?</a>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-success btn-block">Sign in</button>
                                    </div>
                                <?php echo Form::close(); ?>

                                <div class="new-account mt-3">
                                    <p>Don't have an account? <a class="text-primary" href="<?php echo e(URL::to('userSignUp')); ?>">Sign
                                            up</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-md-6">
                        <div class="footer-link text-left" >
                            <a href="#" class="m_logo"><img src="images/w_logo.png" alt=""></a>
                            <a href="#">About</a>
                            <a href="#">Privacy Policy</a>
                            <a href="#">Term & Service</a>
                        </div>
                    </div>
                    <div class="col-xl-6 col-md-6 text-lg-right text-center" style="display: none;">
                        <div class="social">
                            <a href="#"><i class="fa fa-youtube-play"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col-xl-12 text-center text-lg-right">
                        <div class="copy_right text-center text-lg-center">
                            Copyright © 2019 Smart Typing. All Rights Reserved.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="bg_icons"></div>


    <script src="<?php echo e(URL::to('public/website/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('public/website/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('public/website/vendor/waves/waves.min.js')); ?>"></script>

    <!-- <script src="<?php echo e(URL::to('public/website/vendor/validator/jquery.validate.js')); ?>"></script> -->
    <script src="<?php echo e(URL::to('public/website/vendor/validator/validator-init.js')); ?>"></script>

    <script src="<?php echo e(URL::to('public/website/js/scripts.js')); ?>"></script>
</body>
</html>