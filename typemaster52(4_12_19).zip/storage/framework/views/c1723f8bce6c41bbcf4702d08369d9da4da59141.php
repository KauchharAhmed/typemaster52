<!DOCTYPE html>
<html lang="en">
<head>
  <title>Smart-typing</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: gray;font-family: tahoma;">

<div class="container">
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6" style="background-color: #fff;margin-top: 40px;border-radius: 10px;">
          <div class="form" style="padding: 30px;">

            <?php $feeQuery = DB::table('tbl_exam_fee')->first(); ?>
            <h2 style="text-align: center;"><b><u>Payment Here Via Bkash</u></b></h2>
            <center><a href="<?php echo e(URL::to('/')); ?>">Go Back</a></center><br>
            <p style="font-size: 20px;color:red;">Send Registration Fee at <strong>+8801671697082 </strong>(৳<?php echo $feeQuery->amount; ?> included tax.)</p>

            <?php if(Session::get('success') != null) { ?>
            <div class="alert alert-info alert-dismissible" role="alert">
            <a href="#" class="fa fa-times" data-dismiss="alert" aria-label="close"></a>
            <strong><?php echo Session::get('success') ;  ?></strong>
            <?php Session::put('success',null) ;  ?>
            </div>
            <?php } ?>

            <?php
            if(Session::get('failed') != null) { ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
            <a href="#" class="fa fa-times" data-dismiss="alert" aria-label="close"></a>
            <strong><?php echo Session::get('failed') ; ?></strong>
            <?php echo Session::put('failed',null) ; ?>
            </div>
            <?php } ?>

            <?php if(count($errors) > 0): ?>
            <?php foreach($errors->all() as $error): ?>      
            <div class="alert alert-danger alert-dismissible" role="alert">
            <a href="#" class="fa fa-times" data-dismiss="alert" aria-label="close"></a>
            <strong><?php echo e($error); ?></strong>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>

            <?php echo Form::open(['url' =>'paymentRegistrationFee','method' => 'post','role' => 'form']); ?>

              <div class="form-group">
                <label for="email">Amount <span style="color:red;font-weight: bold;">*</span></label>
                <input type="number" class="form-control" placeholder="Amount" name="amount">
              </div>
              <div class="form-group">
                <label for="email">Confirm Amount <span style="color:red;font-weight: bold;">*</span></label>
                <input type="number" class="form-control" placeholder="Confirm Amount" name="confirmAmount">
              </div>
              <div class="form-group">
                <label for="pwd">Sent From <span style="color:red;font-weight: bold;">*</span></label>
                <input type="number" class="form-control" placeholder="Sent From" name="sentBkashNumber">
              </div>
              <div class="form-group">
                <label for="pwd">Transanction ID <span style="color:red;font-weight: bold;">*</span></label>
                <input type="text" class="form-control" placeholder="Transanction ID" name="txrid">
              </div>
              <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
              <input type="hidden" name="random_number_encode" value="<?php echo $random_number_encode; ?>">
              <button type="submit" class="btn btn-primary btn-block">Submit</button>

            <?php echo Form::close(); ?>

          </div>
      </div>
      <div class="col-md-3"></div>
    </div>
</div>

</body>
</html>
