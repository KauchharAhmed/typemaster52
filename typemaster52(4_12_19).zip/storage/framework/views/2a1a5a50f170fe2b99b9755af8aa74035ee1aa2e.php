<h1 style="color:blue;font-family: tahoma;font-size: 40px;font-weight: bolder;text-align: center;margin-top: 250px;">Welcome To Type Master</h1>

<center><a style="font-family: tahoma;font-size: 20px;font-weight: bolder;text-decoration: none;" href="<?php echo e(URL::to('apanel')); ?>">SignIn</a>&nbsp;&nbsp;&nbsp;
<a style="font-family: tahoma;font-size: 20px;font-weight: bolder;text-decoration: none;" href="<?php echo e(URL::to('userSignUp')); ?>">SignUp</a></center>