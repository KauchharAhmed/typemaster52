<?php $__env->startSection('content'); ?>
<div id="page_content">
        <div id="page_content_inner">

            <!-- large chart -->
            <div class="uk-grid">
                <div class="uk-width-1-1">
                    <div class="md-card">
                        <div class="md-card-toolbar" style="color:yellow;background: -webkit-gradient(linear, left top, left bottom, from(#42a1ec), to(#0070c9));background: -webkit-linear-gradient(#42a1ec, #0070c9);background: linear-gradient(#42a1ec, #0070c9);font-size:17px;font-weight:bold;">
                            <h3 class="md-card-toolbar-heading-text" style="color:#fff;font-size:17px;font-weight:bold;">Pay to attend in exam first via Bkash</h3>
                        </div>
                        <div class="md-card-content" style="background:#efffd8;font-size:18px;font-weight:bold;border-bottom:2px solid #42a1ec;border-left:2px solid #42a1ec;border-right:2px solid #42a1ec;text-align:justify;">
                            <p class="paragraph">Send at: 01723626707 (Bkash Personal)</p>
                            
                            <?php echo Form::open(['url' =>'paymentByBkash','method' => 'post','role' => 'form']); ?>


                            <input type="hidden" name="paragraph_id" value="<?php echo e($paragraph_id); ?>">
                            <input type="hidden" name="session_id" value="<?php echo e($session_id); ?>">
                            
                            <table>
                                <tr>
                                    <td style="font-size:14px !important;">Amount</td>
                                    <td><input type="text" name="amount"></td>
                                </tr>
                                <tr>
                                    <td style="font-size:14px !important;">Sent from</td>
                                    <td><input type="text" name="bkash_number"></td>
                                </tr>
                                <tr>
                                    <td style="font-size:14px !important;">Transanction ID</td>
                                    <td><input type="text" name="txrid"></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><input type="submit" class="md-btn md-btn-primary md-btn" id="formSubmit" value="Pay Now"></td>
                                </tr>
                            </table>

                            <?php echo Form::close(); ?>


                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.masterEntrerpreneur', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>